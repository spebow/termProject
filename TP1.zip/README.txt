Use left and right arrow keys to move
Use up arrow key to jump
Press up and a left or right at the same time when on a wall to wall jump
Press A to Grapple
To Grapple, you must be off the floor
You can only grapple off a blue ceiling
press s to squat
You can double jump 
